-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 15, 2024 at 08:26 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `1collegesscholarshipdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `applytb`
--

CREATE TABLE `applytb` (
  `id` bigint(20) NOT NULL auto_increment,
  `UserName` varchar(250) NOT NULL,
  `Mobile` varchar(250) NOT NULL,
  `schloarship` varchar(250) NOT NULL,
  `Certificate1` varchar(500) NOT NULL,
  `Certificate2` varchar(500) NOT NULL,
  `SAmount` varchar(20) NOT NULL,
  `Percentage` varchar(250) NOT NULL,
  `SanctionAmount` varchar(250) NOT NULL,
  `Status` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `applytb`
--

INSERT INTO `applytb` (`id`, `UserName`, `Mobile`, `schloarship`, `Certificate1`, `Certificate2`, `SAmount`, `Percentage`, `SanctionAmount`, `Status`) VALUES
(1, '5535', '9486365535', 'sport', '1tamil8.txt', '1tamilmv77.txt', '', '', '', 'Approved'),
(2, '844101', '9486365535', 'firtst grauade', '76.jpg', '76.jpg', '10', '80', '8.0', 'Approved'),
(3, '22', '8807799441', 'firtst', '76.jpg', '32.png', '100', '80', '80.0', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `schloartb`
--

CREATE TABLE `schloartb` (
  `id` bigint(10) NOT NULL auto_increment,
  `ScholarshipName` varchar(250) NOT NULL,
  `ScholarshipType` varchar(250) NOT NULL,
  `Announced` varchar(250) NOT NULL,
  `Year` varchar(250) NOT NULL,
  `Amount` varchar(250) NOT NULL,
  `Payment` varchar(250) NOT NULL,
  `Certificate1` varchar(250) NOT NULL,
  `Certificate2` varchar(250) NOT NULL,
  `OtherInfo` varchar(500) NOT NULL,
  `Image` varchar(500) NOT NULL,
  `Hash1` varchar(250) NOT NULL,
  `Hash2` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `schloartb`
--

INSERT INTO `schloartb` (`id`, `ScholarshipName`, `ScholarshipType`, `Announced`, `Year`, `Amount`, `Payment`, `Certificate1`, `Certificate2`, `OtherInfo`, `Image`, `Hash1`, `Hash2`) VALUES
(1, 'sport', 'Sports', 'StateGovernment', '2014', '40000', '400', 'marksheet', 'sport', 'dsg', '9367.png', '', ''),
(3, 'firtst', 'Education', 'StateGovernment', '2014', '8000', '100', 'marksheet', 'tc', 'nill', '3445.png', '', '043EE9E79688A70885D69E30B207A25DBB528A440DE7C8C363152D1E525C8229'),
(4, 'first', 'Education', 'StateGovernment', '2014', '8000', '100', 'marksheet', 'marksheet', 'aD', '9588.png', '043EE9E79688A70885D69E30B207A25DBB528A440DE7C8C363152D1E525C8229', 'CFF56189C5A90BF084915DD2B616D6C11037EAE16E7B2A11DECA1921350BE2F1');

-- --------------------------------------------------------

--
-- Table structure for table `studenttb`
--

CREATE TABLE `studenttb` (
  `id` bigint(20) NOT NULL auto_increment,
  `RegisterNo` varchar(250) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Gender` varchar(250) NOT NULL,
  `Mobile` varchar(250) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Department` varchar(250) NOT NULL,
  `Batch` varchar(250) NOT NULL,
  `Year` varchar(250) NOT NULL,
  `Shift` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `studenttb`
--

INSERT INTO `studenttb` (`id`, `RegisterNo`, `Name`, `Gender`, `Mobile`, `Email`, `Address`, `Department`, `Batch`, `Year`, `Shift`) VALUES
(1, '5535', 'sangeeth', 'male', '9486365535', 'sangeeth5535@gmail.com', 'No 16, Samnath Plaza, Madurai Main Road, Melapudhur', 'PG', '2021-2023', 'IYear', 'Morning'),
(3, '234567', 'akash', 'male', '6383109004', 'sangeeth5535@gmail.com', 'No 16, Samnath Plaza, Madurai Main Road, Melapudhur', 'PG', '2021-2023', 'IYear', 'Morning'),
(4, '844101', 'sangeeth Kumar', 'male', '9486365535', 'sangeeth5535@gmail.com', 'No 16, Samnath Plaza, Madurai Main Road, Melapudhur', 'UG', '2022-2024', 'IYear', 'Morning'),
(5, '22', 'ragu', 'male', '8807799441', 'sangeeth5535@gmail.com', 'No 16, Samnath Plaza, Madurai Main Road, Melapudhur', 'UG', '2021-2023', 'IYear', 'Morning');
