-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 22, 2025 at 05:40 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `1collegesscholarshipdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `applytb`
--

CREATE TABLE `applytb` (
  `id` bigint(20) NOT NULL auto_increment,
  `UserName` varchar(250) NOT NULL,
  `Mobile` varchar(250) NOT NULL,
  `schloarship` varchar(250) NOT NULL,
  `Certificate1` varchar(500) NOT NULL,
  `Certificate2` varchar(500) NOT NULL,
  `SAmount` varchar(20) NOT NULL,
  `Percentage` varchar(250) NOT NULL,
  `SanctionAmount` varchar(250) NOT NULL,
  `Status` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `applytb`
--


-- --------------------------------------------------------

--
-- Table structure for table `schloartb`
--

CREATE TABLE `schloartb` (
  `id` bigint(10) NOT NULL auto_increment,
  `ScholarshipName` varchar(250) NOT NULL,
  `ScholarshipType` varchar(250) NOT NULL,
  `Announced` varchar(250) NOT NULL,
  `Year` varchar(250) NOT NULL,
  `Amount` varchar(250) NOT NULL,
  `Payment` varchar(250) NOT NULL,
  `Certificate1` varchar(250) NOT NULL,
  `Certificate2` varchar(250) NOT NULL,
  `OtherInfo` varchar(500) NOT NULL,
  `Image` varchar(500) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `schloartb`
--


-- --------------------------------------------------------

--
-- Table structure for table `studenttb`
--

CREATE TABLE `studenttb` (
  `id` bigint(20) NOT NULL auto_increment,
  `RegisterNo` varchar(250) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Gender` varchar(250) NOT NULL,
  `Mobile` varchar(250) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Department` varchar(250) NOT NULL,
  `Batch` varchar(250) NOT NULL,
  `Year` varchar(250) NOT NULL,
  `Shift` varchar(250) NOT NULL,
  `Password` varchar(250) NOT NULL,
  `CPassword` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `studenttb`
--

