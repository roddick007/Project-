from flask import Flask, render_template, request, session, flash,send_file

import mysql.connector

app = Flask(__name__)
app.config['SECRET_KEY'] = 'aaa'


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/AdminLogin')
def AdminLogin():
    return render_template('AdminLogin.html')


@app.route('/NewStudent')
def NewStudent():
    return render_template('NewStudent.html')


@app.route('/StudentLogin')
def StudentLogin():
    return render_template('StudentLogin.html')


@app.route('/NewScholarship')
def NewScholarship():
    return render_template('NewScholarship.html')


@app.route("/adminlogin", methods=['GET', 'POST'])
def adminlogin():
    error = None
    if request.method == 'POST':
        if request.form['uname'] == 'admin' and request.form['password'] == 'admin':
            conn = mysql.connector.connect(user='root', password='', host='localhost',
                                           database='1collegesscholarshipdb')
            cur = conn.cursor()
            cur.execute("SELECT * FROM studenttb")
            data = cur.fetchall()
            flash("Login Successfully")
            return render_template('AdminHome.html', data=data)


        else:
            return render_template('index.html', error=error)


@app.route("/AdminHome")
def AdminHome():
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM studenttb")
    data = cur.fetchall()
    return render_template('AdminHome.html', data=data)


@app.route("/newsch", methods=['GET', 'POST'])
def newsch():
    if request.method == 'POST':
        regno = request.form['sname']
        uname = request.form['Scholarship']
        gender = request.form['Announced']
        mobile = request.form['year']
        #email = request.form['amt']
        #address = request.form['payment']
        depart = request.form['cer1']
        Batch = request.form['cer2']
        year = request.form['info']
        import random
        #file = request.files['file']
        #fnew = random.randint(1111, 9999)
        #savename = str(fnew) + ".png"
        #file.save("static/upload/" + savename)

        conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
        cursor = conn.cursor()
        cursor.execute(
            "insert into schloartb values('','" + regno + "','" + uname + "','" + gender + "','" + mobile + "','','' ,'" + depart + "','" + Batch + "','" + year + "','nil')")
        conn.commit()
        conn.close()

        flash("Record Saved!")
        return render_template('NewScholarship.html')


@app.route("/Remove")
def Remove():
    id = request.args.get('id')
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cursor = conn.cursor()
    cursor.execute(
        "delete from schloartb where id='" + id + "'")
    conn.commit()
    conn.close()
    flash('scholarship  info Remove Successfully!')
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM schloartb  ")
    data = cur.fetchall()
    return render_template('ScholarshipInfo.html', data=data)


@app.route("/ScholarshipInfo")
def ScholarshipInfo():
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM schloartb  ")
    data = cur.fetchall()
    return render_template('ScholarshipInfo.html', data=data)


@app.route("/newstudent", methods=['GET', 'POST'])
def newstudent():
    if request.method == 'POST':
        regno = request.form['regno']
        uname = request.form['uname']
        gender = request.form['gender']
        mobile = request.form['mobile']
        email = request.form['email']
        address = request.form['Address']
        depart = request.form['depart']
        Batch = request.form['Batch']
        year = request.form['year']
        Shift = request.form['Shift']
        pas = request.form['pas']
        cpas = request.form['cpas']


        conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
        cursor = conn.cursor()
        cursor.execute(
            "insert into studenttb values('','" + regno + "','" + uname + "','" + gender + "','" + mobile + "',"
                                        "'" + email + "','" + address + "' ,'" + depart + "','" + Batch + "','" + year + "',"
                                        "'" + Shift + "','" + pas + "','" + cpas + "')")
        conn.commit()
        conn.close()

        conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
        cur = conn.cursor()
        cur.execute("SELECT * FROM studenttb  ")
        data = cur.fetchall()

        flash("Registered Successfully!")
        return render_template('NewStudent.html', data=data)


@app.route("/studentlogin", methods=['GET', 'POST'])
def studentlogin():
    if request.method == 'POST':
        username = request.form['uname']
        password = request.form['password']
        session['uname'] = request.form['uname']

        conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
        cursor = conn.cursor()
        cursor.execute("SELECT * from studenttb where RegisterNo='" + username + "' and 	Password='" + password + "'")
        data = cursor.fetchone()
        if data is None:
            return render_template('index.html')
            return 'Username or Password is wrong'
        else:

            session['mob']= data[4]

            flash("you are successfully logged in")

            return render_template('Search.html')


@app.route('/StudentHome')
def StudentHome():

    regno = session['uname']
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM studenttb where RegisterNo='" + regno + "' ")
    data = cur.fetchall()
    return render_template('StudentHome.html', data=data)


@app.route("/Search")
def Search():

    return render_template('Search.html')


@app.route("/search", methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        Scholarship = request.form['Scholarship']

        conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
        cur = conn.cursor()
        cur.execute("SELECT * FROM schloartb  where ScholarshipType='" + Scholarship + "'")
        data = cur.fetchall()
        return render_template('Search.html', data=data)


@app.route("/Apply")
def Apply():
    id = request.args.get('id')
    mob = request.args.get('mob')
    session['id'] = id

    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cursor = conn.cursor()
    cursor.execute("SELECT  *  FROM schloartb  where  id='" + id + "'")
    data = cursor.fetchone()

    if data:
        sname = data[1]
        pay = data[6]


    else:
        return 'No Record Found!'

    return render_template('Apply.html', sname=sname, pay=pay)


@app.route("/apply", methods=['GET', 'POST'])
def apply():
    if request.method == 'POST':
        sname = request.form['sname']
        #payment = request.form['payment']
        mark = request.form['Mark']
        #pmark = (float(mark) / 100) * float(payment)
        file1 = request.files['file1']
        file1.save("static/upload/" + file1.filename)
        file2 = request.files['file2']
        file2.save("static/upload/" + file2.filename)

        conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
        cursor = conn.cursor()
        cursor.execute(
            "insert into applytb values('','" + session['uname'] + "','"+ session['mob'] +"','" + sname + "','" + file1.filename + "','" + file2.filename + "','','"+ mark +"','','waiting')")
        conn.commit()
        conn.close()
        flash('scholarship  Submitted Successfully!')
        return render_template('Status.html')


@app.route("/Status")
def Status():
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM applytb where UserName='" + session['uname'] + "'   ")
    data = cur.fetchall()
    return render_template('Status.html', data=data)


@app.route("/ApplyInfo")
def ApplyInfo():
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM applytb where status='waiting'   ")
    data = cur.fetchall()
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM applytb")
    data1 = cur.fetchall()
    return render_template('ApplyInfo.html', data=data,data1=data1)


@app.route("/Accept")
def Accept():
    id = request.args.get('id')
    mob = request.args.get('mob')
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cursor = conn.cursor()
    cursor.execute(
        "update  applytb set status='Approved' where id='" + id + "'")
    conn.commit()
    conn.close()
    flash('scholarship  info Approved Successfully!')
    sendmsg(mob, 'scholarship  info Approved Successfully!')
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM applytb where status='waiting' ")
    data = cur.fetchall()

    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM applytb where status !='waiting' ")
    data1 = cur.fetchall()
    return render_template('ScholarshipInfo.html', data=data,data1=data1)


@app.route("/Reject")
def Reject():
    id = request.args.get('id')
    mob = request.args.get('mob')
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cursor = conn.cursor()
    cursor.execute(
        "update  applytb set status='Reject' where id='" + id + "'")
    conn.commit()
    conn.close()
    flash('scholarship  info Reject !')
    sendmsg(mob,'cholarship  info Reject')
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM applytb where status='waiting' ")
    data = cur.fetchall()

    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM applytb where status !='waiting' ")
    data1 = cur.fetchall()


    return render_template('ScholarshipInfo.html', data=data,data1=data1)

@app.route("/down1")
def down1():
    id = request.args.get('id')
    print(id)
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cursor = conn.cursor()
    cursor.execute("SELECT * from applytb where id ='" + id + "'   ")
    data = cursor.fetchone()
    if data is None:

        return 'Assingment Not Upload'
    else:
        print(data[4])
        filename = data[4]

        return send_file('static/upload/' + filename, as_attachment=True)
@app.route("/down2")
def down2():
    id = request.args.get('id')
    print(id)

    conn = mysql.connector.connect(user='root', password='', host='localhost', database='1collegesscholarshipdb')
    cursor = conn.cursor()
    cursor.execute("SELECT * from applytb where id ='" + id + "'   ")
    data = cursor.fetchone()
    if data is None:

        return 'Assingment Not Upload'
    else:
        print(data[5])
        filename = data[5]

        return send_file('static/upload/' + filename, as_attachment=True)

def sendmsg(targetno,message):
    import requests
    requests.post("http://smsserver9.creativepoint.in/api.php?username=fantasy&password=596692&to=" + targetno + "&from=FSSMSS&message=Dear user  your msg is " + message + " Sent By FSMSG FSSMSS&PEID=1501563800000030506&templateid=1507162882948811640")





if __name__ == '__main__':
    app.run(debug=True, use_reloader=True)
